/****************************************************************************
** Meta object code from reading C++ file 'KeyboardVisDlg.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "KeyboardVisualizerQT/KeyboardVisDlg.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'KeyboardVisDlg.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Ui__KeyboardVisDlg_t {
    QByteArrayData data[26];
    char stringdata0[843];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Ui__KeyboardVisDlg_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Ui__KeyboardVisDlg_t qt_meta_stringdata_Ui__KeyboardVisDlg = {
    {
QT_MOC_LITERAL(0, 0, 18), // "Ui::KeyboardVisDlg"
QT_MOC_LITERAL(1, 19, 6), // "update"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 9), // "show_hide"
QT_MOC_LITERAL(4, 37, 45), // "on_lineEdit_Background_Bright..."
QT_MOC_LITERAL(5, 83, 4), // "arg1"
QT_MOC_LITERAL(6, 88, 33), // "on_lineEdit_Amplitude_textCha..."
QT_MOC_LITERAL(7, 122, 36), // "on_lineEdit_Average_Size_text..."
QT_MOC_LITERAL(8, 159, 29), // "on_lineEdit_Decay_textChanged"
QT_MOC_LITERAL(9, 189, 29), // "on_lineEdit_Delay_textChanged"
QT_MOC_LITERAL(10, 219, 44), // "on_lineEdit_Normalization_Off..."
QT_MOC_LITERAL(11, 264, 43), // "on_lineEdit_Normalization_Sca..."
QT_MOC_LITERAL(12, 308, 39), // "on_lineEdit_Animation_Speed_t..."
QT_MOC_LITERAL(13, 348, 47), // "on_comboBox_FFT_Window_Mode_c..."
QT_MOC_LITERAL(14, 396, 5), // "index"
QT_MOC_LITERAL(15, 402, 47), // "on_comboBox_Background_Mode_c..."
QT_MOC_LITERAL(16, 450, 47), // "on_comboBox_Foreground_Mode_c..."
QT_MOC_LITERAL(17, 498, 49), // "on_comboBox_Single_Color_Mode..."
QT_MOC_LITERAL(18, 548, 44), // "on_comboBox_Average_Mode_curr..."
QT_MOC_LITERAL(19, 593, 35), // "on_pushButton_Save_Settings_c..."
QT_MOC_LITERAL(20, 629, 39), // "on_checkBox_Reactive_Backgrou..."
QT_MOC_LITERAL(21, 669, 7), // "checked"
QT_MOC_LITERAL(22, 677, 44), // "on_comboBox_Audio_Device_curr..."
QT_MOC_LITERAL(23, 722, 39), // "on_lineEdit_Filter_Constant_t..."
QT_MOC_LITERAL(24, 762, 37), // "on_checkBox_Silent_Background..."
QT_MOC_LITERAL(25, 800, 42) // "on_lineEdit_Background_Timeou..."

    },
    "Ui::KeyboardVisDlg\0update\0\0show_hide\0"
    "on_lineEdit_Background_Brightness_textChanged\0"
    "arg1\0on_lineEdit_Amplitude_textChanged\0"
    "on_lineEdit_Average_Size_textChanged\0"
    "on_lineEdit_Decay_textChanged\0"
    "on_lineEdit_Delay_textChanged\0"
    "on_lineEdit_Normalization_Offset_textChanged\0"
    "on_lineEdit_Normalization_Scale_textChanged\0"
    "on_lineEdit_Animation_Speed_textChanged\0"
    "on_comboBox_FFT_Window_Mode_currentIndexChanged\0"
    "index\0on_comboBox_Background_Mode_currentIndexChanged\0"
    "on_comboBox_Foreground_Mode_currentIndexChanged\0"
    "on_comboBox_Single_Color_Mode_currentIndexChanged\0"
    "on_comboBox_Average_Mode_currentIndexChanged\0"
    "on_pushButton_Save_Settings_clicked\0"
    "on_checkBox_Reactive_Background_clicked\0"
    "checked\0on_comboBox_Audio_Device_currentIndexChanged\0"
    "on_lineEdit_Filter_Constant_textChanged\0"
    "on_checkBox_Silent_Background_clicked\0"
    "on_lineEdit_Background_Timeout_textChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Ui__KeyboardVisDlg[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x08 /* Private */,
       3,    0,  120,    2, 0x08 /* Private */,
       4,    1,  121,    2, 0x08 /* Private */,
       6,    1,  124,    2, 0x08 /* Private */,
       7,    1,  127,    2, 0x08 /* Private */,
       8,    1,  130,    2, 0x08 /* Private */,
       9,    1,  133,    2, 0x08 /* Private */,
      10,    1,  136,    2, 0x08 /* Private */,
      11,    1,  139,    2, 0x08 /* Private */,
      12,    1,  142,    2, 0x08 /* Private */,
      13,    1,  145,    2, 0x08 /* Private */,
      15,    1,  148,    2, 0x08 /* Private */,
      16,    1,  151,    2, 0x08 /* Private */,
      17,    1,  154,    2, 0x08 /* Private */,
      18,    1,  157,    2, 0x08 /* Private */,
      19,    0,  160,    2, 0x08 /* Private */,
      20,    1,  161,    2, 0x08 /* Private */,
      22,    1,  164,    2, 0x08 /* Private */,
      23,    1,  167,    2, 0x08 /* Private */,
      24,    1,  170,    2, 0x08 /* Private */,
      25,    1,  173,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::QString,    5,

       0        // eod
};

void Ui::KeyboardVisDlg::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<KeyboardVisDlg *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->update(); break;
        case 1: _t->show_hide(); break;
        case 2: _t->on_lineEdit_Background_Brightness_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->on_lineEdit_Amplitude_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->on_lineEdit_Average_Size_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_lineEdit_Decay_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->on_lineEdit_Delay_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->on_lineEdit_Normalization_Offset_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->on_lineEdit_Normalization_Scale_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->on_lineEdit_Animation_Speed_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_comboBox_FFT_Window_Mode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_comboBox_Background_Mode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_comboBox_Foreground_Mode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_comboBox_Single_Color_Mode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_comboBox_Average_Mode_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_pushButton_Save_Settings_clicked(); break;
        case 16: _t->on_checkBox_Reactive_Background_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->on_comboBox_Audio_Device_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_lineEdit_Filter_Constant_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->on_checkBox_Silent_Background_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->on_lineEdit_Background_Timeout_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Ui::KeyboardVisDlg::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_Ui__KeyboardVisDlg.data,
    qt_meta_data_Ui__KeyboardVisDlg,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Ui::KeyboardVisDlg::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Ui::KeyboardVisDlg::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Ui__KeyboardVisDlg.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Ui::KeyboardVisDlg::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
