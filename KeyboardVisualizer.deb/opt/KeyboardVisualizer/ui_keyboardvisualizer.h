/********************************************************************************
** Form generated from reading UI file 'keyboardvisualizer.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KEYBOARDVISUALIZER_H
#define UI_KEYBOARDVISUALIZER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_KeyboardVisualizerDlg
{
public:
    QWidget *centralWidget;
    QLabel *label_Amplitude;
    QLineEdit *lineEdit_Amplitude;
    QLabel *label_Background_Brightness;
    QLineEdit *lineEdit_Background_Brightness;
    QLabel *label_Average_Size;
    QLineEdit *lineEdit_Average_Size;
    QLabel *label_Decay;
    QLineEdit *lineEdit_Decay;
    QLabel *label_Delay;
    QLineEdit *lineEdit_Delay;
    QLabel *label_Normalization_Offset;
    QLineEdit *lineEdit_Normalization_Offset;
    QLabel *label_Normalization_Scale;
    QLineEdit *lineEdit_Normalization_Scale;
    QLabel *label_FFT_Window_Mode;
    QComboBox *comboBox_FFT_Window_Mode;
    QLabel *label_Background_Mode;
    QComboBox *comboBox_Background_Mode;
    QLabel *label_Foreground_Mode;
    QComboBox *comboBox_Foreground_Mode;
    QLabel *label_Single_Color_Mode;
    QComboBox *comboBox_Single_Color_Mode;
    QLabel *label_Average_Mode;
    QComboBox *comboBox_Average_Mode;
    QLabel *label_Animation_Speed;
    QLineEdit *lineEdit_Animation_Speed;
    QGraphicsView *graphicsView_Visualization_Preview;
    QLabel *label_Visualization_Preview;
    QPushButton *pushButton_Save_Settings;
    QLabel *label_GitHub_URL;
    QCheckBox *checkBox_Reactive_Background;
    QLabel *label_Reactive_Background;
    QLabel *label_Audio_Device;
    QComboBox *comboBox_Audio_Device;
    QLineEdit *lineEdit_Filter_Constant;
    QLabel *label_Filter_Constant;
    QCheckBox *checkBox_Silent_Background;
    QLabel *label_Silent_Background;
    QLineEdit *lineEdit_Background_Timeout;
    QLabel *label_Background_Timeout;

    void setupUi(QMainWindow *KeyboardVisualizerDlg)
    {
        if (KeyboardVisualizerDlg->objectName().isEmpty())
            KeyboardVisualizerDlg->setObjectName(QString::fromUtf8("KeyboardVisualizerDlg"));
        KeyboardVisualizerDlg->resize(600, 360);
        centralWidget = new QWidget(KeyboardVisualizerDlg);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label_Amplitude = new QLabel(centralWidget);
        label_Amplitude->setObjectName(QString::fromUtf8("label_Amplitude"));
        label_Amplitude->setGeometry(QRect(10, 10, 140, 16));
        lineEdit_Amplitude = new QLineEdit(centralWidget);
        lineEdit_Amplitude->setObjectName(QString::fromUtf8("lineEdit_Amplitude"));
        lineEdit_Amplitude->setGeometry(QRect(150, 5, 130, 25));
        label_Background_Brightness = new QLabel(centralWidget);
        label_Background_Brightness->setObjectName(QString::fromUtf8("label_Background_Brightness"));
        label_Background_Brightness->setGeometry(QRect(10, 40, 140, 16));
        lineEdit_Background_Brightness = new QLineEdit(centralWidget);
        lineEdit_Background_Brightness->setObjectName(QString::fromUtf8("lineEdit_Background_Brightness"));
        lineEdit_Background_Brightness->setGeometry(QRect(150, 35, 130, 25));
        label_Average_Size = new QLabel(centralWidget);
        label_Average_Size->setObjectName(QString::fromUtf8("label_Average_Size"));
        label_Average_Size->setGeometry(QRect(10, 70, 140, 16));
        lineEdit_Average_Size = new QLineEdit(centralWidget);
        lineEdit_Average_Size->setObjectName(QString::fromUtf8("lineEdit_Average_Size"));
        lineEdit_Average_Size->setGeometry(QRect(150, 65, 130, 25));
        label_Decay = new QLabel(centralWidget);
        label_Decay->setObjectName(QString::fromUtf8("label_Decay"));
        label_Decay->setGeometry(QRect(10, 100, 140, 16));
        lineEdit_Decay = new QLineEdit(centralWidget);
        lineEdit_Decay->setObjectName(QString::fromUtf8("lineEdit_Decay"));
        lineEdit_Decay->setGeometry(QRect(150, 95, 130, 25));
        label_Delay = new QLabel(centralWidget);
        label_Delay->setObjectName(QString::fromUtf8("label_Delay"));
        label_Delay->setGeometry(QRect(10, 130, 140, 16));
        lineEdit_Delay = new QLineEdit(centralWidget);
        lineEdit_Delay->setObjectName(QString::fromUtf8("lineEdit_Delay"));
        lineEdit_Delay->setGeometry(QRect(150, 125, 130, 25));
        label_Normalization_Offset = new QLabel(centralWidget);
        label_Normalization_Offset->setObjectName(QString::fromUtf8("label_Normalization_Offset"));
        label_Normalization_Offset->setGeometry(QRect(10, 160, 140, 16));
        lineEdit_Normalization_Offset = new QLineEdit(centralWidget);
        lineEdit_Normalization_Offset->setObjectName(QString::fromUtf8("lineEdit_Normalization_Offset"));
        lineEdit_Normalization_Offset->setGeometry(QRect(150, 155, 130, 25));
        label_Normalization_Scale = new QLabel(centralWidget);
        label_Normalization_Scale->setObjectName(QString::fromUtf8("label_Normalization_Scale"));
        label_Normalization_Scale->setGeometry(QRect(10, 190, 140, 16));
        lineEdit_Normalization_Scale = new QLineEdit(centralWidget);
        lineEdit_Normalization_Scale->setObjectName(QString::fromUtf8("lineEdit_Normalization_Scale"));
        lineEdit_Normalization_Scale->setGeometry(QRect(150, 185, 130, 25));
        label_FFT_Window_Mode = new QLabel(centralWidget);
        label_FFT_Window_Mode->setObjectName(QString::fromUtf8("label_FFT_Window_Mode"));
        label_FFT_Window_Mode->setGeometry(QRect(290, 10, 140, 16));
        comboBox_FFT_Window_Mode = new QComboBox(centralWidget);
        comboBox_FFT_Window_Mode->setObjectName(QString::fromUtf8("comboBox_FFT_Window_Mode"));
        comboBox_FFT_Window_Mode->setGeometry(QRect(440, 5, 150, 25));
        label_Background_Mode = new QLabel(centralWidget);
        label_Background_Mode->setObjectName(QString::fromUtf8("label_Background_Mode"));
        label_Background_Mode->setGeometry(QRect(290, 40, 140, 16));
        comboBox_Background_Mode = new QComboBox(centralWidget);
        comboBox_Background_Mode->setObjectName(QString::fromUtf8("comboBox_Background_Mode"));
        comboBox_Background_Mode->setGeometry(QRect(440, 35, 150, 25));
        label_Foreground_Mode = new QLabel(centralWidget);
        label_Foreground_Mode->setObjectName(QString::fromUtf8("label_Foreground_Mode"));
        label_Foreground_Mode->setGeometry(QRect(290, 70, 140, 16));
        comboBox_Foreground_Mode = new QComboBox(centralWidget);
        comboBox_Foreground_Mode->setObjectName(QString::fromUtf8("comboBox_Foreground_Mode"));
        comboBox_Foreground_Mode->setGeometry(QRect(440, 65, 150, 25));
        label_Single_Color_Mode = new QLabel(centralWidget);
        label_Single_Color_Mode->setObjectName(QString::fromUtf8("label_Single_Color_Mode"));
        label_Single_Color_Mode->setGeometry(QRect(290, 100, 140, 16));
        comboBox_Single_Color_Mode = new QComboBox(centralWidget);
        comboBox_Single_Color_Mode->setObjectName(QString::fromUtf8("comboBox_Single_Color_Mode"));
        comboBox_Single_Color_Mode->setGeometry(QRect(440, 95, 150, 25));
        label_Average_Mode = new QLabel(centralWidget);
        label_Average_Mode->setObjectName(QString::fromUtf8("label_Average_Mode"));
        label_Average_Mode->setGeometry(QRect(290, 130, 140, 16));
        comboBox_Average_Mode = new QComboBox(centralWidget);
        comboBox_Average_Mode->setObjectName(QString::fromUtf8("comboBox_Average_Mode"));
        comboBox_Average_Mode->setGeometry(QRect(440, 125, 150, 25));
        label_Animation_Speed = new QLabel(centralWidget);
        label_Animation_Speed->setObjectName(QString::fromUtf8("label_Animation_Speed"));
        label_Animation_Speed->setGeometry(QRect(290, 190, 140, 16));
        lineEdit_Animation_Speed = new QLineEdit(centralWidget);
        lineEdit_Animation_Speed->setObjectName(QString::fromUtf8("lineEdit_Animation_Speed"));
        lineEdit_Animation_Speed->setGeometry(QRect(440, 185, 150, 25));
        graphicsView_Visualization_Preview = new QGraphicsView(centralWidget);
        graphicsView_Visualization_Preview->setObjectName(QString::fromUtf8("graphicsView_Visualization_Preview"));
        graphicsView_Visualization_Preview->setGeometry(QRect(150, 275, 256, 64));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(graphicsView_Visualization_Preview->sizePolicy().hasHeightForWidth());
        graphicsView_Visualization_Preview->setSizePolicy(sizePolicy);
        graphicsView_Visualization_Preview->setMinimumSize(QSize(256, 64));
        graphicsView_Visualization_Preview->setMaximumSize(QSize(256, 64));
        graphicsView_Visualization_Preview->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        graphicsView_Visualization_Preview->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        graphicsView_Visualization_Preview->setInteractive(false);
        label_Visualization_Preview = new QLabel(centralWidget);
        label_Visualization_Preview->setObjectName(QString::fromUtf8("label_Visualization_Preview"));
        label_Visualization_Preview->setGeometry(QRect(10, 280, 140, 16));
        pushButton_Save_Settings = new QPushButton(centralWidget);
        pushButton_Save_Settings->setObjectName(QString::fromUtf8("pushButton_Save_Settings"));
        pushButton_Save_Settings->setGeometry(QRect(440, 275, 150, 25));
        label_GitHub_URL = new QLabel(centralWidget);
        label_GitHub_URL->setObjectName(QString::fromUtf8("label_GitHub_URL"));
        label_GitHub_URL->setGeometry(QRect(10, 340, 581, 16));
        checkBox_Reactive_Background = new QCheckBox(centralWidget);
        checkBox_Reactive_Background->setObjectName(QString::fromUtf8("checkBox_Reactive_Background"));
        checkBox_Reactive_Background->setGeometry(QRect(440, 215, 150, 26));
        label_Reactive_Background = new QLabel(centralWidget);
        label_Reactive_Background->setObjectName(QString::fromUtf8("label_Reactive_Background"));
        label_Reactive_Background->setGeometry(QRect(290, 220, 140, 20));
        label_Audio_Device = new QLabel(centralWidget);
        label_Audio_Device->setObjectName(QString::fromUtf8("label_Audio_Device"));
        label_Audio_Device->setGeometry(QRect(290, 160, 140, 16));
        comboBox_Audio_Device = new QComboBox(centralWidget);
        comboBox_Audio_Device->setObjectName(QString::fromUtf8("comboBox_Audio_Device"));
        comboBox_Audio_Device->setGeometry(QRect(440, 155, 150, 27));
        lineEdit_Filter_Constant = new QLineEdit(centralWidget);
        lineEdit_Filter_Constant->setObjectName(QString::fromUtf8("lineEdit_Filter_Constant"));
        lineEdit_Filter_Constant->setGeometry(QRect(150, 215, 130, 25));
        label_Filter_Constant = new QLabel(centralWidget);
        label_Filter_Constant->setObjectName(QString::fromUtf8("label_Filter_Constant"));
        label_Filter_Constant->setGeometry(QRect(10, 220, 140, 16));
        checkBox_Silent_Background = new QCheckBox(centralWidget);
        checkBox_Silent_Background->setObjectName(QString::fromUtf8("checkBox_Silent_Background"));
        checkBox_Silent_Background->setGeometry(QRect(440, 245, 150, 26));
        label_Silent_Background = new QLabel(centralWidget);
        label_Silent_Background->setObjectName(QString::fromUtf8("label_Silent_Background"));
        label_Silent_Background->setGeometry(QRect(290, 250, 140, 20));
        lineEdit_Background_Timeout = new QLineEdit(centralWidget);
        lineEdit_Background_Timeout->setObjectName(QString::fromUtf8("lineEdit_Background_Timeout"));
        lineEdit_Background_Timeout->setGeometry(QRect(150, 245, 130, 25));
        label_Background_Timeout = new QLabel(centralWidget);
        label_Background_Timeout->setObjectName(QString::fromUtf8("label_Background_Timeout"));
        label_Background_Timeout->setGeometry(QRect(10, 250, 140, 16));
        KeyboardVisualizerDlg->setCentralWidget(centralWidget);

        retranslateUi(KeyboardVisualizerDlg);

        QMetaObject::connectSlotsByName(KeyboardVisualizerDlg);
    } // setupUi

    void retranslateUi(QMainWindow *KeyboardVisualizerDlg)
    {
        KeyboardVisualizerDlg->setWindowTitle(QApplication::translate("KeyboardVisualizerDlg", "Keyboard Visualizer 3.06", nullptr));
        label_Amplitude->setText(QApplication::translate("KeyboardVisualizerDlg", "Amplitude (%)", nullptr));
        label_Background_Brightness->setText(QApplication::translate("KeyboardVisualizerDlg", "Background Brightness", nullptr));
        label_Average_Size->setText(QApplication::translate("KeyboardVisualizerDlg", "Average Size", nullptr));
        label_Decay->setText(QApplication::translate("KeyboardVisualizerDlg", "Decay (% per step)", nullptr));
        label_Delay->setText(QApplication::translate("KeyboardVisualizerDlg", "Delay (ms)", nullptr));
        label_Normalization_Offset->setText(QApplication::translate("KeyboardVisualizerDlg", "Normalization Offset", nullptr));
        label_Normalization_Scale->setText(QApplication::translate("KeyboardVisualizerDlg", "Normalization Scale", nullptr));
        label_FFT_Window_Mode->setText(QApplication::translate("KeyboardVisualizerDlg", "FFT Window Mode", nullptr));
        label_Background_Mode->setText(QApplication::translate("KeyboardVisualizerDlg", "Background Mode", nullptr));
        label_Foreground_Mode->setText(QApplication::translate("KeyboardVisualizerDlg", "Foreground Mode", nullptr));
        label_Single_Color_Mode->setText(QApplication::translate("KeyboardVisualizerDlg", "Single Color Mode", nullptr));
        label_Average_Mode->setText(QApplication::translate("KeyboardVisualizerDlg", "Average Mode", nullptr));
        label_Animation_Speed->setText(QApplication::translate("KeyboardVisualizerDlg", "Animation Speed", nullptr));
        label_Visualization_Preview->setText(QApplication::translate("KeyboardVisualizerDlg", "Visualization Preview", nullptr));
        pushButton_Save_Settings->setText(QApplication::translate("KeyboardVisualizerDlg", "Save Settings", nullptr));
        label_GitHub_URL->setText(QApplication::translate("KeyboardVisualizerDlg", "https://github.com/CalcProgrammer1/KeyboardVisualizer", nullptr));
        checkBox_Reactive_Background->setText(QString());
        label_Reactive_Background->setText(QApplication::translate("KeyboardVisualizerDlg", "Reactive Background", nullptr));
        label_Audio_Device->setText(QApplication::translate("KeyboardVisualizerDlg", "Audio Device", nullptr));
        label_Filter_Constant->setText(QApplication::translate("KeyboardVisualizerDlg", "Filter Constant", nullptr));
        checkBox_Silent_Background->setText(QString());
        label_Silent_Background->setText(QApplication::translate("KeyboardVisualizerDlg", "Silent Background", nullptr));
        label_Background_Timeout->setText(QApplication::translate("KeyboardVisualizerDlg", "Background Timeout", nullptr));
    } // retranslateUi

};

namespace Ui {
    class KeyboardVisualizerDlg: public Ui_KeyboardVisualizerDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KEYBOARDVISUALIZER_H
